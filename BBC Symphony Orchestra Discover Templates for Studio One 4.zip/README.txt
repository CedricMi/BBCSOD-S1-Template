BBC SO Discover Template for Presonus Studio One 4 by Cédric Mialaret
BBC SO Discover Simple Template for Presonus Studio One 4 by Cédric Mialaret

Unzip the content of this archive under <Your Studio One Content Folder>/templates/v4
On Windows, it is generally under C:\Users\YourName\Documents\Studio One
On macOS please see Studio One documentation


Copyright (C) 2020 Cédric Mialaret
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.